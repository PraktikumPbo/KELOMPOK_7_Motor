﻿using Microsoft.AspNetCore.Mvc;
using MotorRentalSystem.Models;
using MotorRentalSystem.Repository;

namespace MotorRentalSystem.Controllers
{
    public class MotorController : Controller
    {
        private readonly IData data;

        public MotorController(IData _data)
        {
            data = _data;
        }

        public IActionResult Index()
        {
            var list = data.GetAllMotors();
            return View(list); 
        }
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Add(Motor newmotor)
        {
            if (!ModelState.IsValid)
                return View(newmotor);
            bool isSaved = data.AddNewMotor(newmotor);
            ViewBag.IsSaved = isSaved;
            ModelState.Clear();

            ViewBag.isSaved = true;
            return View();
        }
    }
}
