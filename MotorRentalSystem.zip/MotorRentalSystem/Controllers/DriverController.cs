﻿using Microsoft.AspNetCore.Mvc;
using MotorRentalSystem.Models;
using MotorRentalSystem.Repository;

namespace MotorRentalSystem.Controllers
{
    public class DriverController : Controller
    {
        private readonly IData data;
        public DriverController(IData _data)
        {
            data = _data;
        }
        public IActionResult Index()
        {
            var list = data.GetAllDrivers();
            return View(list);
        }

        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Add(Driver driver)
        {
            if(!ModelState.IsValid)
                return View(driver);
            ViewBag.isSaved = data.AddDriver(driver);
            ModelState.Clear();
            return View();
        }
       
    }
}
