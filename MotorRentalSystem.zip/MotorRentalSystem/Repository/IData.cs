﻿using MotorRentalSystem.Models;
namespace MotorRentalSystem.Repository
{
    public interface IData
    {
        bool AddNewMotor(Motor newmotor);

        List<Motor> GetAllMotors();

        bool AddDriver(Driver newdriver);
        List<Driver> GetAllDrivers();
        bool BookingNow(Rent rent);
        List<string> GetBrand();
        List<string> GetModel(string brand);
        List<Rent> GetAllRents();



        
    }
}
