﻿using MotorRentalSystem.Models;
using System.Data.OleDb;
using System.Drawing.Printing;
using System.Runtime.Versioning;
using Microsoft.AspNetCore.Hosting;

namespace MotorRentalSystem.Repository
{
    public class Data : IData
    {
        private readonly IConfiguration configuration;
        private readonly string dbcon = "";
        private readonly IWebHostEnvironment webHost;
        private List<Rent> rents;

        public Data(IConfiguration configuration, IWebHostEnvironment webHost)
        {
            this.configuration = configuration;
            dbcon = this.configuration.GetConnectionString("dbConnection ");
            this.webHost = webHost;
        }
        [SupportedOSPlatform("windows")]
        public List<Rent> GetAllRents()
        {
            List<Rent> rents = new List<Rent>();
            Rent rent;
            OleDbConnection con = GetOleDbConnection();
            try
            {
                con.Open();
                string qry = "Select * from Rents;";
                OleDbDataReader reader = GetData(qry, con);
                while (reader.Read())
                {
                    rent = new Rent();
                    rent.Id = int.Parse(reader["ID"].ToString());
                    rent.PickUp = reader["PickUp"].ToString();
                    rent.DropOff = reader["DropOff"].ToString();
                    rent.PickUpDate = Convert.ToDateTime(reader["PickUpDate"].ToString());
                    rent.DropOffDate = Convert.ToDateTime(reader["DropOffDate"].ToString());
                    rent.TotalRun = int.Parse(reader["TotalRun"].ToString());
                    rent.Rate = int.Parse(reader["Rate"].ToString());
                    rent.Brand = reader["Brand"].ToString();
                    rent.Model = reader["Model"].ToString();
                    rent.DriverId = int.Parse(reader["DriverId"].ToString());
                    rent.CustomerName = reader["CustomerName"].ToString();
                    rent.CustomerContact = reader["CustomerContactNo"].ToString();
                    rents.Add(rent);
                }
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                con.Close();
            }
            return rents;
        }
        [SupportedOSPlatform("windows")]
        public List<string> GetModel(string brand)
        {
            List<string> model = new List<string>();
            OleDbConnection con = GetOleDbConnection();
            try
            {
                con.Open();
                string qry = "Select distinct Model from Motor where Brand='" + brand + "'";
                OleDbDataReader reader = GetData(qry, con);
                while (reader.Read())
                {
                    model.Add(reader["Model"].ToString());
                }

            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                con.Close();
            }
            return model;
        }

        [SupportedOSPlatform("windows")]
        public List<string> GetBrand()
        {
            List<string> brand = new List<string>();
            OleDbConnection con = GetOleDbConnection();
            try
            {
                con.Open();
                string qry = "Select distinct Brand from Motor;";
                OleDbDataReader reader = GetData(qry, con);
                while (reader.Read())       
                {
                    brand.Add(reader["Brand"].ToString());
                }
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                con.Close();
            }
            return brand;
        }
        [SupportedOSPlatform("windows")]
        public bool BookingNow(Rent rent)
        {
            bool isSaved = false;
            OleDbConnection con = GetOleDbConnection();
            try
            {
                con.Open();
                rent.TotalAmount = rent.TotalRun * rent.Rate;
                string qry = String.Format("Insert into Rents(PickUp,DropOff,PickUpDate,DropOffDate,TotalRun,Rate,TotalAmount,Brand,Model,DriverId,CustomerName,CustomerContactNo) values(" +
                    "'{0}','{1}','{2}','{3}',{4},{5},{6},'{7}','{8}',{9},'{10}','{11}')", 
                    rent.PickUp, rent.DropOff, rent.PickUpDate, rent.DropOffDate, rent.TotalRun,rent.Rate,
                    rent.TotalAmount,rent.Brand,rent.Model,rent.DriverId,rent.CustomerName,rent.CustomerContact);
                isSaved = SaveData(qry, con);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
            return isSaved;
        }

        [SupportedOSPlatform("windows")]
        
        public List<Driver> GetAllDrivers()
        {
            List<Driver> drivers = new List<Driver>();
            Driver dr;
            OleDbConnection con = GetOleDbConnection();
            try
            {
                con.Open();
                string qry = "Select * from Driver;";
                OleDbDataReader reader = GetData(qry, con);
                while (reader.Read())
                {
                    dr = new Driver();
                    dr.Id = int.Parse(reader["ID"].ToString());
                    dr.Name = reader["DriverName"].ToString();
                    dr.Address = reader["Address"].ToString();
                    dr.MobileNo = reader["MobileNo"].ToString();
                    dr.Age = int.Parse(reader["Age"].ToString());
                    dr.Experience = int.Parse(reader["Experience"].ToString());

                    drivers.Add(dr);
                }
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                con.Close();
            }
            return drivers;
        }

        [SupportedOSPlatform("windows")]
        public bool AddDriver(Driver newdriver)
        {
            bool isSaved = false;
            OleDbConnection con = GetOleDbConnection();
            try
            {
                con.Open();
               

                string qry = String.Format("Insert into Driver(DriverName,Address,MobileNo,Age,Experience) values(" +
                    " '{0}','{1}','{2}',{3},{4})", newdriver.Name, newdriver.Address, newdriver.MobileNo, newdriver.Age, newdriver.Experience);
                isSaved = SaveData(qry, con);
            } 
            catch (Exception)
            {

                throw;
            }
            finally
            {
                con.Close();
            }
            return isSaved;
        }
        [SupportedOSPlatform("windows")]
        public List<Motor> GetAllMotors()
        {
            List<Motor> motors = new List<Motor>();
            Motor motor;
            OleDbConnection con = GetOleDbConnection();
            try
            {
                con.Open();
                string qry = "Select * from Motor";
                OleDbDataReader reader = GetData(qry, con);
                while (reader.Read())
                {
                    motor = new Motor();
                    motor.Id = int.Parse(reader["ID"].ToString());
                    motor.Brand = reader["Brand"].ToString();
                    motor.Model = reader["model"].ToString();
                    motor.PassingYear = int.Parse(reader["PassingYear"].ToString());
                    motor.Engine = reader["Engine"].ToString();
                    motor.FuelType = reader["FuelType"].ToString();
                    motor.ImagePath = reader["ImagePath"].ToString();
                    motor.MotorNumber = reader["MotorNumber"].ToString();
                    motor.SeatingCapacity = int.Parse(reader["SeatingCapacity"].ToString());
                    motors.Add(motor);
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
            return motors;
        }
        [SupportedOSPlatform("windows")]
        private OleDbDataReader GetData(string qry, OleDbConnection con)
        {
            OleDbDataReader reader = null;
            try
            {
                OleDbCommand cmd = new OleDbCommand(qry, con);
                reader = cmd.ExecuteReader();
            }
            catch (Exception)
            {
                throw;
            }
            return reader;
        }
        [SupportedOSPlatform("windows")]
        public bool AddNewMotor(Motor newmotor)
        {
            bool isSaved = false;
            OleDbConnection con =GetOleDbConnection();
            try
            {
                con.Open();
                newmotor.ImagePath = SaveImage(newmotor.MotorImage, "motor");

                string qry = String.Format("Insert into Motor(Brand,Model,PassingYear,MotorNumber,Engine,FuelType,ImagePath,SeatingCapacity) values(" + 
                    "'{0}','{1}',{2},'{3}','{4}','{5}','{6}',{7})", newmotor.Brand,newmotor.Model,newmotor.PassingYear,newmotor.MotorNumber,
                    newmotor.Engine,newmotor.FuelType,newmotor.ImagePath,newmotor.SeatingCapacity);
                isSaved = SaveData(qry, con);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
            return isSaved;
        }
        private string SaveImage(IFormFile file,string folderName)
        {
            string imagepath = "";
            try
            {
                string uploadfolder = Path.Combine(webHost.WebRootPath,"images/"+folderName);
                imagepath = Guid.NewGuid().ToString() + "_" + file.FileName;
                string filepath = Path.Combine(uploadfolder,imagepath);
                using(var filestream = new FileStream(filepath, FileMode.Create))
                {
                    file.CopyTo(filestream);
                }
            }
            catch (Exception)
            {

                throw;
            }
            return imagepath;
        }
        [SupportedOSPlatform("windows")] //adding because ms acces support in windows only
        private OleDbConnection GetOleDbConnection()
        {
            return new OleDbConnection(dbcon);
        }
        [SupportedOSPlatform("windows")]
        private bool SaveData(string qry, OleDbConnection con)
        {
            bool isSaved = false;
            try
            {
                OleDbCommand cmd = new OleDbCommand(qry, con);
                cmd.ExecuteNonQuery();
                isSaved = true;


            }
            catch (Exception)
            {
                throw;
            }
            return isSaved;    
        }
        

    }
}
