﻿namespace MotorRentalSystem.Models
{
    public class DriverBase1
    {
    }
}